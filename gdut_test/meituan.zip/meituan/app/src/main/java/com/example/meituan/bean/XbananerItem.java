package com.example.meituan.bean;

import com.stx.xhb.androidx.entity.BaseBannerInfo;

/**
 * @author :yinxiaolong
 * @describe : com.example.meituan.bean
 * @date :2023/5/11 16:29
 */
public class XbananerItem implements BaseBannerInfo {


    public XbananerItem(String url) {
        this.url = url;
    }

    String url;
    @Override
    public Object getXBannerUrl() {
        return url;
    }

    @Override
    public String getXBannerTitle() {
        return null;
    }
}
