package com.example.meituan.adapter;

/**
 * @author :yinxiaolong
 * @describe : com.example.meituan.adapter
 * @date :2023/5/12 11:13
 */
public interface MyOnItemClickListener {
        void onItemClick(int position);
}
