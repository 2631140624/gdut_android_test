package com.example.meituan;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.example.meituan.adapter.MyOnItemClickListener;
import com.example.meituan.adapter.RecyclerBusinessAdapter;
import com.example.meituan.bean.Business;
import com.example.meituan.bean.XbananerItem;
import com.example.meituan.databinding.ActivityMainBinding;
import com.stx.xhb.androidx.XBanner;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    XBanner mXBanner;
    ActivityMainBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding=ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        initBanner();
        initRecycler();
    }
    private void initRecycler(){
        List<Business> list=new ArrayList<>();
        list.add(new Business("xxx","快乐柠檬","起送￥20|配送￥5","月销1024","广外大街饮品回头率第五名","配送约30分钟"));
        list.add(new Business("xxx","悲伤小猫","起送￥20|配送￥5","月销1024","广外大街饮品回头率第五名","配送约30分钟"));
        list.add(new Business("xxx","天天开心","起送￥20|配送￥5","月销1024","广外大街饮品回头率第五名","配送约30分钟"));
        list.add(new Business("xxx","快块炸鸡","起送￥20|配送￥5","月销1024","广外大街饮品回头率第五名","配送约30分钟"));
        list.add(new Business("xxx","速速开吃","起送￥20|配送￥5","月销1024","广外大街饮品回头率第五名","配送约30分钟"));

        RecyclerBusinessAdapter adapter=new RecyclerBusinessAdapter(list);

        adapter.setOnItemClickListener(new MyOnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                startActivity(new Intent(MainActivity.this,SealActivity.class));
            }
        });
        binding.recyclerBusiness.setLayoutManager(new LinearLayoutManager(this));
        binding.recyclerBusiness.setAdapter(adapter);
    }
    private void initBanner(){
        mXBanner= findViewById(R.id.xbanner);

        //代码设置框架占位图，也可在布局中设置
        mXBanner.setBannerPlaceholderImg(R.mipmap.ic_launcher, ImageView.ScaleType.CENTER_CROP);
        List<XbananerItem> items=new ArrayList<>();
        items.add(new XbananerItem("https://xiaolong-1307792394.cos.ap-guangzhou.myqcloud.com/img/image-20230511163730215.png"));
        items.add(new XbananerItem("https://xiaolong-1307792394.cos.ap-guangzhou.myqcloud.com/img/image-20230511163817918.png"));
        //添加轮播图片数据（图片数据不局限于网络图片、本地资源文件、View 都可以）,刷新数据也是调用该方法
        mXBanner.setBannerData(items);//setData（）方法已过时，推荐使用setBannerData（）方法，具体参照demo使用
        //加载广告图片
        mXBanner.loadImage(new XBanner.XBannerAdapter() {
            @Override
            public void loadBanner(XBanner banner, Object model, View view, int position) {
                //1、此处使用的Glide加载图片，可自行替换自己项目中的图片加载框架
                //2、返回的图片路径为Object类型，你只需要强转成你传输的类型就行，切记不要胡乱强转！
                Glide.with(MainActivity.this).load(((XbananerItem) model).getXBannerUrl()).into((ImageView) view);
            }
        });

    }
}