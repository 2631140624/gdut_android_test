package com.example.meituan.bean;

import android.widget.ImageView;

/**
 * @author :yinxiaolong
 * @describe : com.example.meituan.bean
 * @date :2023/5/11 17:03
 */
public class Business {
    private String imageUrl;
    private String name;
    private String price;
    private String sale_count;
    private String describe;
    private String peisongTime;


    public Business(String imageUrl, String name, String price, String sale_count, String describe, String peisongTime) {
        this.imageUrl = imageUrl;
        this.name = name;
        this.price = price;
        this.sale_count = sale_count;
        this.describe = describe;
        this.peisongTime = peisongTime;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getSale_count() {
        return sale_count;
    }

    public void setSale_count(String sale_count) {
        this.sale_count = sale_count;
    }

    public String getDescribe() {
        return describe;
    }

    public void setDescribe(String describe) {
        this.describe = describe;
    }

    public String getPeisongTime() {
        return peisongTime;
    }

    public void setPeisongTime(String peisongTime) {
        this.peisongTime = peisongTime;
    }
}
