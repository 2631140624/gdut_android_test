package com.example.meituan;

import android.app.Application;
import android.content.Context;

/**
 * @author :yinxiaolong
 * @describe : com.example.meituan
 * @date :2023/5/18 15:43
 */
public class app extends Application {

    public  static Context context;
    @Override
    public void onCreate() {
        super.onCreate();
        context=getApplicationContext();
    }
}
