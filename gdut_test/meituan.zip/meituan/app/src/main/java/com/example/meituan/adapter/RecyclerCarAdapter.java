package com.example.meituan.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.meituan.bean.Business;
import com.example.meituan.databinding.CarListBinding;
import com.example.meituan.databinding.RecyclerBusinessItemBinding;

import java.util.List;

/**
 * @author :yinxiaolong
 * @describe : com.example.meituan.adapter
 * @date :2023/5/17 15:48
 */
public class RecyclerCarAdapter extends RecyclerView.Adapter<RecyclerCarAdapter.ViewHolder> {


    List<Business> businessList;

    public RecyclerCarAdapter(List<Business> businessList) {
        this.businessList = businessList;
    }

    @NonNull
    @Override
    public RecyclerCarAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        CarListBinding binding=CarListBinding.inflate(LayoutInflater.from(parent.getContext()),parent,false);
        return new ViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerCarAdapter.ViewHolder holder, int position) {
            holder.binding.carListTvName.setText(businessList.get(position).getName());
            holder.binding.carListTvPrice.setText(businessList.get(position).getPrice());
    }

    @Override
    public int getItemCount() {
        return businessList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        CarListBinding binding;
        public ViewHolder(@NonNull CarListBinding binding) {
            super(binding.getRoot());
            this.binding=binding;
        }
    }
}
