package com.example.meituan;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;

import com.example.meituan.adapter.MyOnItemClickListener;
import com.example.meituan.adapter.RecyclerCarAdapter;
import com.example.meituan.adapter.RecyclerSealAdapter;
import com.example.meituan.bean.Business;
import com.example.meituan.databinding.ActivitySealBinding;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.orhanobut.dialogplus.DialogPlus;
import com.orhanobut.dialogplus.ListHolder;
import com.orhanobut.dialogplus.OnItemClickListener;
import com.orhanobut.dialogplus.ViewHolder;

import java.util.ArrayList;
import java.util.List;


public class SealActivity extends AppCompatActivity {

    ActivitySealBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivitySealBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        binding.top.button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        initUI();
        //去到结算页面
        binding.car.btnGo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                startActivity(new Intent(SealActivity.this,PayActivity.class));
            }
        });


        //弹出购物车列表
        binding.car.imageView2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                List<Business> list=new ArrayList<>();
                list.add(new Business("xxx","珍珠奶茶","￥20","门店销量第5名","月销335好评度100%",""));
                list.add(new Business("xxx","珍珠奶茶","￥20","门店销量第5名","月销335好评度100%",""));
                list.add(new Business("xxx","珍珠奶茶","￥20","门店销量第5名","月销335好评度100%",""));
                list.add(new Business("xxx","珍珠奶茶","￥20","门店销量第5名","月销335好评度100%",""));
                BottomSheetDialog sheetDialog=new BottomSheetDialog(SealActivity.this);
                View view1= LayoutInflater.from(SealActivity.this).inflate(R.layout.bottom_sheet,null);

                RecyclerView recyclerView=view1.findViewById(R.id.recycler_car);
                recyclerView.setLayoutManager(new LinearLayoutManager(SealActivity.this));
                RecyclerCarAdapter adapter
                        =new RecyclerCarAdapter(list);


                recyclerView.setAdapter(adapter);
                sheetDialog.setContentView(view1);
                sheetDialog.show();
            }
        });
    }

    private void initUI() {


        List<Business> list=new ArrayList<>();

        list.add(new Business("xxx","珍珠奶茶","￥20","门店销量第5名","月销335好评度100%",""));
        list.add(new Business("xxx","珍珠奶茶","￥20","门店销量第5名","月销335好评度100%",""));
        list.add(new Business("xxx","珍珠奶茶","￥20","门店销量第5名","月销335好评度100%",""));
        list.add(new Business("xxx","珍珠奶茶","￥20","门店销量第5名","月销335好评度100%",""));

        RecyclerSealAdapter adapter=new RecyclerSealAdapter(list);
        binding.recyclerSeal.setLayoutManager(new LinearLayoutManager(this));
        binding.recyclerSeal.setAdapter(adapter);

        adapter.setOnItemClickListener(new MyOnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                DialogPlus dialog = DialogPlus.newDialog(SealActivity.this)
                        .setGravity(Gravity.CENTER)
                        .setContentHolder(new ViewHolder(R.layout.detail))
                        .setMargin(300, 100, 200, 50)
                       // .setAdapter(adapter)
                        .setOnItemClickListener(new OnItemClickListener() {
                            @Override
                            public void onItemClick(DialogPlus dialog, Object item, View view, int position) {
                            }
                        })
                        .setCancelable(true)
                        .setExpanded(true)  // This will enable the expand feature, (similar to android L share dialog)
                        .create();
                dialog.show();
            }
        });

    }
}