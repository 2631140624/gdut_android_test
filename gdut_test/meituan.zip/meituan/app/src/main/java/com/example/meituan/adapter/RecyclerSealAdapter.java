package com.example.meituan.adapter;

/**
 * @author :yinxiaolong
 * @describe : com.example.meituan.adapter
 * @date :2023/5/12 16:56
 */

import static com.example.meituan.app.context;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.meituan.R;
import com.example.meituan.bean.Business;
import com.example.meituan.databinding.RecyclerSealItemBinding;

import java.util.List;
import java.util.Random;

/**
 * @author :yinxiaolong
 * @describe : com.example.meituan.adapter
 * @date :2023/5/11 17:01
 */
public class RecyclerSealAdapter extends RecyclerView.Adapter<RecyclerSealAdapter.ViewHolder> {

    List<Business> list;

    //监听事件
    private MyOnItemClickListener listener;


    public void setOnItemClickListener(MyOnItemClickListener listener) {
        this.listener = listener;
    }

    public RecyclerSealAdapter(List<Business> list) {
        this.list = list;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        RecyclerSealItemBinding binding=RecyclerSealItemBinding.inflate(LayoutInflater.from(parent.getContext()),parent,false);
        return new ViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerSealAdapter.ViewHolder holder, int position) {
        holder.binding.tvSealItemName.setText(list.get(position).getName());
        holder.binding.tvItemSealcount2.setText(list.get(position).getDescribe());
        holder.binding.tvSealItemPrice.setText(list.get(position).getPrice());
        holder.binding.tvSealItemSealcount.setText(list.get(position).getSale_count());


        holder.binding.imgSealItem.setImageResource(getRandomDrawableResId());


    }
    private int getRandomDrawableResId(){

        int a=new Random().nextInt(11);
        return context.getResources().getIdentifier("img_"+a, "drawable", context.getPackageName());

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {


        RecyclerSealItemBinding binding;

        public ViewHolder(@NonNull RecyclerSealItemBinding binding) {
            super(binding.getRoot());

            this.binding=binding;
            binding.getRoot().setOnClickListener(this);//这里不会创建额外的匿名内部类对象，因为ViewHolder对象本来就是要被创建的

        }

        @Override
        public void onClick(View view) {
            if (listener != null) {
                int position = getAdapterPosition();
                listener.onItemClick(position);
            }
        }
    }
}
