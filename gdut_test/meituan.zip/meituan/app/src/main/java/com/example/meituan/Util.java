package com.example.meituan;

import static com.example.meituan.app.context;

import java.util.Random;

/**
 * @author :yinxiaolong
 * @describe : com.example.meituan
 * @date :2023/5/18 15:52
 */
public class Util {
    public static int getRandomDrawableResId(){

        int a=new Random().nextInt(11);
        return context.getResources().getIdentifier("img_"+a, "drawable", context.getPackageName());

    }
}
